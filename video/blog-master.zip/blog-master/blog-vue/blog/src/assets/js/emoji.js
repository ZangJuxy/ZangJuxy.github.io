export default {
  "[微笑]": "https://www.static.talkxj.com/emoji/smile.jpg",

  "[笑]": " https://www.static.talkxj.com/emoji/dx.jpg",

  "[呲牙]": "https://www.static.talkxj.com/emoji/cy.jpg",

  "[OK]": "https://www.static.talkxj.com/emoji/ok.jpg",

  "[星星眼]": "https://www.static.talkxj.com/emoji/xxy.jpg",

  "[哦呼]": "https://www.static.talkxj.com/emoji/oh.jpg",

  "[嫌弃]": "https://www.static.talkxj.com/emoji/xq.jpg",

  "[喜欢]": "https://www.static.talkxj.com/emoji/xh.jpg",

  "[酸了]": "https://www.static.talkxj.com/emoji/sl.jpg",

  "[大哭]": "https://www.static.talkxj.com/emoji/dq.jpg?",

  "[害羞]": "https://www.static.talkxj.com/emoji/hx.jpg",

  "[无语]": "https://www.static.talkxj.com/emoji/wy.jpg",

  "[疑惑]": "https://www.static.talkxj.com/emoji/yh.jpg",

  "[调皮]": "https://www.static.talkxj.com/emoji/tiaopi.jpg",

  "[笑哭]": "https://www.static.talkxj.com/emoji/xiaoku.jpg",

  "[奸笑]": "https://www.static.talkxj.com/emoji/jianxiao.jpg",

  "[偷笑]": "https://www.static.talkxj.com/emoji/touxiao.jpg",

  "[大笑]": "https://www.static.talkxj.com/emoji/daxiao.jpg",

  "[阴险]": "https://www.static.talkxj.com/emoji/yinxian.jpg",

  "[捂脸]": "https://www.static.talkxj.com/emoji/wulian.jpg",

  "[呆]": "https://www.static.talkxj.com/emoji/dai.jpg",

  "[抠鼻]": "https://www.static.talkxj.com/emoji/koubi.jpg",

  "[惊喜]": "https://www.static.talkxj.com/emoji/jingxi.jpg",

  "[惊讶]": "https://www.static.talkxj.com/emoji/jingya.jpg",

  "[捂脸哭]": "https://www.static.talkxj.com/emoji/wulianku.jpg",

  "[妙啊]": "https://www.static.talkxj.com/emoji/miaoa.jpg",

  "[狗头]": "https://www.static.talkxj.com/emoji/goutou.jpg",

  "[滑稽]": "https://www.static.talkxj.com/emoji/huaji.jpg",

  "[吃瓜]": "https://www.static.talkxj.com/emoji/chigua.jpg",

  "[打call]": "https://www.static.talkxj.com/emoji/dacall.jpg",

  "[点赞]": "https://www.static.talkxj.com/emoji/dianzan.jpg",

  "[鼓掌]": "https://www.static.talkxj.com/emoji/guzhang.jpg",

  "[尴尬]": "https://www.static.talkxj.com/emoji/ganga.jpg",

  "[冷]": "https://www.static.talkxj.com/emoji/leng.jpg",

  "[灵魂出窍]": "https://www.static.talkxj.com/emoji/linghunchuqiao.jpg",

  "[委屈]": "https://www.static.talkxj.com/emoji/weiqu.jpg",

  "[傲娇]": "https://www.static.talkxj.com/emoji/aojiao.jpg",

  "[疼]": "https://www.static.talkxj.com/emoji/teng.jpg",

  "[吓]": "https://www.static.talkxj.com/emoji/xia.jpg?",

  "[生病]": "https://www.static.talkxj.com/emoji/shengbing.jpg",

  "[吐]": "https://www.static.talkxj.com/emoji/tu.jpg",

  "[嘘声]": "https://www.static.talkxj.com/emoji/xusheng.jpg",

  "[捂眼]": "https://www.static.talkxj.com/emoji/wuyan.jpg",

  "[思考]": "https://www.static.talkxj.com/emoji/sikao.jpg",

  "[再见]": "https://www.static.talkxj.com/emoji/zaijian.jpg",

  "[翻白眼]": "https://www.static.talkxj.com/emoji/fanbaiyan.jpg",

  "[哈欠]": "https://www.static.talkxj.com/emoji/haqian.jpg",

  "[奋斗]": "https://www.static.talkxj.com/emoji/fengdou.jpg",

  "[墨镜]": "https://www.static.talkxj.com/emoji/mojing.jpg",

  "[撇嘴]": "https://www.static.talkxj.com/emoji/piezui.jpg",

  "[难过]": "https://www.static.talkxj.com/emoji/nanguo.jpg",

  "[抓狂]": "https://www.static.talkxj.com/emoji/zhuakuang.jpg",

  "[生气]": "https://www.static.talkxj.com/emoji/shengqi.jpg",

  "[爱心]": "https://www.static.talkxj.com/emoji/aixin.jpg",

  "[胜利]": "https://www.static.talkxj.com/emoji/shengli.jpg",

  "[保佑]": "https://www.static.talkxj.com/emoji/baoyou.jpg",

  "[支持]": "https://www.static.talkxj.com/emoji/zhichi.jpg"
};
