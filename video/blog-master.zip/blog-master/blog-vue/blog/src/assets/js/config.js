export default {
  QQ_APP_ID: "101878726",
  QQ_REDIRECT_URI: "https://www.talkxj.com/oauth/login/qq",
  WEIBO_APP_ID: "4039197195",
  WEIBO_REDIRECT_URI: "https://www.talkxj.com/oauth/login/weibo",
  TENCENT_CAPTCHA: "2088053498"
};
