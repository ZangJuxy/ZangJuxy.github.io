export default {
  TENCENT_CAPTCHA: "2088053498",
  UPLOAD_SIZE: 200 // 压缩文件大小
};
